import snowflake.connector
import pandas as pd
import datetime 
from Strategy import Strategy
from Client import Client

class Trade:
    """This is the main class named Trade, which contains ohlcv/indicators data and eable to evaluate/apply strategies         
    """

    def __init__(self):
        """The constructor."""
        self.crypto_data = {}  #Creating a dict of crypto data
        self.indicators = {}   #Creating a dict of indicators data

        con_eb = snowflake.connector.connect(user='karimhabib',      #Initializing snowflake connector
                                     password='Internsatos1',
                                     account='au28416.switzerland-north.azure', 
                                     warehouse='COMPUTE_WH', 
                                     database='TRADING',       
                                     schema ='INDICATEURS',
                                     autocommit=True)

        #Getting bitcoin ohlcv data
        query_ohlcv = 'select * from VIEW_OHLCV_1DAY order by DAY asc;'
        self.crypto_data["BTCUSDT"] = pd.read_sql(con = con_eb,  sql = query_ohlcv)

        #Getting indicators data
        query_indicators = 'select DAY,  avg(CLOSE) OVER(ORDER BY DAY ROWS BETWEEN 20 PRECEDING and CURRENT ROW) as valeur from view_ohlcv_1day;'
        self.indicators["MA20"] = pd.read_sql(con = con_eb,  sql = query_indicators)

        #Getting indicators data
        query_indicators = 'select DAY,  avg(CLOSE) OVER(ORDER BY DAY ROWS BETWEEN 50 PRECEDING and CURRENT ROW) as valeur from view_ohlcv_1day;'
        self.indicators["MA50"] = pd.read_sql(con = con_eb,  sql = query_indicators)

        #Initializing an initial client
        self.client = Client()
        



    """ GETTING INFORMATION """

    def get_btcusdt_data(self):
        """Get BTCUSDT data"""
        return self.crypto_data["BTCUSDT"]

    
    def get_indicator_data(self, name):
        """Get Indicator data"""
        return self.indicators[name]




    """ GETING CURRENT INFORMATION """

    def current_price(self):
        """Return the current value of bitcoin"""
        return float(self.get_btcusdt_data().tail(1)["CLOSE"]) 

    def client_goods(self):
        """Return the client's wallet amount"""
        return self.get_client_bitcoin() * self.current_price() + self.get_client_dollar()




    """ GETING PAST INFORMATION """

    def data_day(self, time):
        """Return bitcoin data of day j"""
        return self.get_btcusdt_data().loc[self.get_btcusdt_data()['DAY'] == time]

    def price_day(self, time):
        """Return bitcoin price of day j"""
        return float(self.data_day(time)["CLOSE"])

    def client_goods_day(self, time):
        """Return the client's wallet amount in day j"""
        return self.client.get_bitcoin() * self.price_day(time) + self.client.get_dollar()
        

    def get_indicator_data_day(self, time, name):
        """Return indicator of day j"""
        return self.get_indicator_data(name).loc[self.get_indicator_data(name)['DAY'] == time]




    """ APPLYING DECISIONS """

    def apply_decision(self, next_move, time):
        """Apply decision based on the next calculated move """
        if(next_move == 1):
            self.client.set_bitcoin(self.client.get_dollar() / self.price_day(time))
            self.client.set_dollar(0)
            self.client.set_status(1)
            
        elif(next_move == -1):
            self.client.set_dollar(self.client.get_bitcoin() * self.price_day(time))
            self.client.set_bitcoin(0)
            self.client.set_status(-1)
            



    """ APPLYING DECISIONS """

    def evaluate_strategy(self, strategy, start_time, end_time):
        """Evaluate strategy in a period of time"""
        goods_result = []
        day_delta = datetime.timedelta(days=1)
        
        for i in range((end_time - start_time).days):
            current_time = start_time + i * day_delta
            goods_result.append(self.client_goods_day(current_time))
            next_move = strategy.ma20_50(self.data_day(current_time), [self.get_indicator_data_day(current_time, 'MA20'), self.get_indicator_data_day(current_time, 'MA50')], self.client.get_status())
            self.apply_decision(next_move, current_time)
        
        return goods_result
