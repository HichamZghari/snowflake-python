from Trade import Trade
from Strategy import Strategy
import datetime 
import matplotlib.pyplot as plt

if __name__ == '__main__':
    t = Trade()
    s1 = Strategy()
    d1 = datetime.date(2020, 1, 1)
    d2 = datetime.date(2022, 1, 10)
    X = []

    for i in range((d2 - d1).days):
        X.append(i)
    Y = t.evaluate_strategy(s1, d1, d2)
    
    print(Y)
    plt.plot(X,Y)
    plt.show()
