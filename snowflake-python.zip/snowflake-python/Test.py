from Trade import Trade
from Strategy import Strategy
from Client import Client
import unittest
import datetime 

class TestTrade(unittest.TestCase):
    
    def test_Client(self):
        my_client = Client()
    
        self.assertAlmostEqual(my_client.get_bitcoin(), 0)
        self.assertAlmostEqual(my_client.get_dollar(), 10000)
        self.assertAlmostEqual(my_client.get_status(), -1)
        
        my_client.set_bitcoin(10)
        self.assertAlmostEqual(my_client.get_bitcoin(), 10)
        my_client.set_dollar(88)
        self.assertAlmostEqual(my_client.get_dollar(), 88)
        my_client.set_status(1)
        self.assertAlmostEqual(my_client.get_status(), 1)

    def test_Strategy(self):
        my_strategy = Strategy()
        my_trade = Trade()
        day1 = datetime.date(2022, 1, 1)
        day2 = datetime.date(2018, 4, 9)


        self.assertAlmostEqual(my_strategy.ma20_50([], [my_trade.get_indicator_data_day(day1, 'MA20'), my_trade.get_indicator_data_day(day1, 'MA50')], 1), -1)
        self.assertAlmostEqual(my_strategy.ma20_50([], [my_trade.get_indicator_data_day(day2, 'MA20'), my_trade.get_indicator_data_day(day2, 'MA50')], 1), -1)
  

    def test_Trade(self):
        my_trade = Trade()

        day1 = datetime.date(2022, 1, 1)
        day2 = datetime.date(2018, 4, 9)

        self.assertAlmostEqual(my_trade.price_day(day1), 47722.66)
        self.assertAlmostEqual(my_trade.price_day(day2), 6781.55)

        self.assertAlmostEqual(float(my_trade.get_indicator_data_day(day1, 'MA20')["VALEUR"]), 48296.890952381)
        self.assertAlmostEqual(float(my_trade.get_indicator_data_day(day2, 'MA20')["VALEUR"]), 7584.939047619)
        self.assertAlmostEqual(float(my_trade.get_indicator_data_day(day1, 'MA50')["VALEUR"]), 52887.308431373)
        self.assertAlmostEqual(float(my_trade.get_indicator_data_day(day2, 'MA50')["VALEUR"]), 8907.890784314)


    
if __name__ == '__main__':
    unittest.main()