class Client:
    """This class contains informations about clients:
                                               dollar:  the amount of dollar in  wallet
                                               bitcoin: the amount of bitcoin in wallet
                                               status:  1 for buying, -1 for selling
    """
    
    def __init__(self):
        """The constructor."""
        self.dollar = 10000
        self.bitcoin = 0
        self.status = -1

    """################################# GETTING INFORMATION #################################################"""


    def get_bitcoin(self):
        """Get the client's bitcoin amount.
        """
        return self.bitcoin
    
    def get_dollar(self):
        """Get the client's dollar amount.
        """
        return self.dollar

    def get_status(self):
        """Get the client's status.
        """
        return self.status




    """################################# SETING INFORMATION #################################################"""

    def set_bitcoin(self, val):
        """Set the client's bitcoin amout"""
        self.bitcoin = val
    
    def set_dollar(self, val):
        """Set the client's dollar amout"""
        self.dollar = val

    def set_status(self, val):
        """Set the client's status"""
        self.status = val





