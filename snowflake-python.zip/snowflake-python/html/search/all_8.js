var searchData=
[
  ['set_5fbitcoin_16',['set_bitcoin',['../classClient_1_1Client.html#a5d1642d622ff9d4ca25540e06b6ee906',1,'Client::Client']]],
  ['set_5fdollar_17',['set_dollar',['../classClient_1_1Client.html#a6060366d313f4e24d0e0aabab97c4ab8',1,'Client::Client']]],
  ['set_5fstatus_18',['set_status',['../classClient_1_1Client.html#a96b78e4bd66f560cc4fab97318508aa3',1,'Client::Client']]],
  ['strategy_19',['Strategy',['../classStrategy_1_1Strategy.html',1,'Strategy']]]
];
