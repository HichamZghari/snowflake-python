var searchData=
[
  ['strategy_23',['Strategy',['../classStrategy_1_1Strategy.html',1,'Strategy']]]
];
