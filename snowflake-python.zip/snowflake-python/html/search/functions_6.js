var searchData=
[
  ['ma20_5f50_39',['ma20_50',['../classStrategy_1_1Strategy.html#a331ad0b88c730984c6769bfdc19612d1',1,'Strategy::Strategy']]]
];
