var searchData=
[
  ['evaluate_5fstrategy_32',['evaluate_strategy',['../classTrade_1_1Trade.html#a4c42e995cb10c12981c189c8ca5e5530',1,'Trade::Trade']]]
];
