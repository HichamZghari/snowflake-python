var searchData=
[
  ['data_5fday_6',['data_day',['../classTrade_1_1Trade.html#a9b1bfdfe3c43ebbfe3a19d3ab9acd74f',1,'Trade::Trade']]]
];
