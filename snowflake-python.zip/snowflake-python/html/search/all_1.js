var searchData=
[
  ['apply_5fdecision_1',['apply_decision',['../classTrade_1_1Trade.html#ac583ae801ea03b2a95c761986968d954',1,'Trade::Trade']]]
];
