var searchData=
[
  ['client_5fgoods_28',['client_goods',['../classTrade_1_1Trade.html#a707a64b7c8b725b6aa36ce649e48c6f4',1,'Trade::Trade']]],
  ['client_5fgoods_5fday_29',['client_goods_day',['../classTrade_1_1Trade.html#ab5b7ade3d0fa99ae227296b0ecc9973e',1,'Trade::Trade']]],
  ['current_5fprice_30',['current_price',['../classTrade_1_1Trade.html#a256b2498431bfd04abaa0d4a8bf2aab1',1,'Trade::Trade']]]
];
