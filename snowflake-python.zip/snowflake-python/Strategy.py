class Strategy:
    """This class contains strategies and functions"""

     
    def ma20_50(self, data, indicator, status):
        """This is an example of calculating strategy based on ma20-50 (moving average 20/50-period)"""
        if(status == -1):
            if( float(indicator[0]["VALEUR"]) > float(indicator[1]["VALEUR"])):
                return 1
        elif(status == 1):
            if(float(indicator[0]["VALEUR"]) < float(indicator[1]["VALEUR"])):
                return -1
        
        return 0